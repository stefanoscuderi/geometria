def area(base, altura):
    if base <= 0 or altura <= 0:
        return "Digite um valor de entrada valido"
    return base * altura


def perimetro(base, altura):
    if base <= 0 or altura <= 0:
        return "Digite um valor de entrada valido"
    return (2 * base) + (2 * altura)


